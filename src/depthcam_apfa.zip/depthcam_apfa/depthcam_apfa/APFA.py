import rclpy
import numpy as np
from rclpy.node import Node

from sensor_msgs.msg import Image, NavSatFix
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge

from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy


class ControllerNode(Node):

    def __init__(self, goal_global):

        super().__init__('controller_node')

        # ---------- GLOBAL GOAL ----------
        self.goal_lat = goal_global[0]
        self.goal_lon = goal_global[1]

        
        self.home_lat = None
        self.home_lon = None

       
        self.ka = 0.5
        self.kr = 400.0
        self.ktheta = 0.96

        self.gstar = 4.0
        self.eps_orient = np.pi / 3
        self.eps_control = 1.0

        
        self.bridge = CvBridge()
        self.ControlVel = Twist()

        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        self.create_subscription(
            Odometry,
            '/mavros/local_position/odom',
            self.OdometryCallback,
            qos
        )

        self.create_subscription(
            Image,
            '/camera/camera/depth/image_rect_raw',
            self.DepthcamCallback,
            qos
        )

        self.create_subscription(
            NavSatFix,
            '/mavros/global_position/global',
            self.GpsCallback,
            qos
        )

        self.VelocityPublisher = self.create_publisher(
            Twist,
            '/mavros/setpoint_velocity/cmd_vel_unstamped',
            10
        )

        self.OdometryMessage = None
        self.DepthcamMessage = None

       
        self.fov_horizontal_deg = 87.0
        self.fov_horizontal_rad = np.deg2rad(self.fov_horizontal_deg)

        self.range_min = 0.6
        self.range_max = 6.0

        self.controller_timer = self.create_timer(0.05, self.Controller)

  
    def OdometryCallback(self, msg):
        self.OdometryMessage = msg

    def DepthcamCallback(self, msg):
        self.DepthcamMessage = msg

    def GpsCallback(self, msg):
        if self.home_lat is None:
            self.home_lat = msg.latitude
            self.home_lon = msg.longitude
            self.get_logger().info(
                f"Home set: lat={self.home_lat}, lon={self.home_lon}"
            )


    def global_to_local_xy(self, lat, lon):
        R = 6378137.0  # Earth radius (meters)

        lat1 = np.deg2rad(self.home_lat)
        lon1 = np.deg2rad(self.home_lon)
        lat2 = np.deg2rad(lat)
        lon2 = np.deg2rad(lon)

        dlat = lat2 - lat1
        dlon = lon2 - lon1

        x = R * dlon * np.cos(lat1)   # East
        y = R * dlat                  # North

        return x, y

    

    def Controller(self):

        if (
            self.OdometryMessage is None or
            self.DepthcamMessage is None or
            self.home_lat is None
        ):
            return

       
        self.x = self.OdometryMessage.pose.pose.position.x
        self.y = self.OdometryMessage.pose.pose.position.y

        q = self.OdometryMessage.pose.pose.orientation
        theta = np.arctan2(
            2.0 * (q.w * q.z + q.x * q.y),
            1.0 - 2.0 * (q.y ** 2 + q.z ** 2)
        )

       
        self.xd, self.yd = self.global_to_local_xy(
            self.goal_lat,
            self.goal_lon
        )

        vector = np.array([[self.xd - self.x], [self.yd - self.y]])

       
        try:
            cv_image = self.bridge.imgmsg_to_cv2(
                self.DepthcamMessage,
                desired_encoding='passthrough'
            )
            depth_array = np.array(cv_image, dtype=np.int16)
        except Exception as e:
            self.get_logger().error(str(e))
            return

        depth_array = np.nan_to_num(depth_array, nan=100.0, posinf=100.0)

        center_row = depth_array.shape[0] // 2
        roi_height = 30
        depth_strip = depth_array[
            center_row - roi_height // 2 : center_row + roi_height // 2, :
        ]

        virtual_scan = np.min(depth_strip, axis=0)[::5]
        angles = np.linspace(
            self.fov_horizontal_rad / 2,
            -self.fov_horizontal_rad / 2,
            len(virtual_scan)
        )

        point_obstacles = []
        for d, a in zip(virtual_scan, angles):
            if self.range_min < d < self.range_max:
                point_obstacles.append(
                    (d * np.cos(a), d * np.sin(a), d, a)
                )

     
        clusters = []
        current = []
        for i in range(len(point_obstacles)):
            if not current:
                current.append(point_obstacles[i])
                continue
            x1, y1, _, _ = current[-1]
            x2, y2, _, _ = point_obstacles[i]
            if np.hypot(x2 - x1, y2 - y1) < 0.5:
                current.append(point_obstacles[i])
            else:
                if len(current) >= 2:
                    clusters.append(current)
                current = [point_obstacles[i]]

        if current:
            clusters.append(current)

        Fa = self.ka * vector
        Fr = np.zeros((2, 1))

        for cluster in clusters:
            closest = min(cluster, key=lambda p: p[2])
            _, _, g, alpha = closest
            if g > self.gstar:
                continue

            mag = self.kr * (1.0 / g - 1.0 / self.gstar) / (g ** 2)
            Fr -= np.array([
                [mag * np.cos(alpha + theta)],
                [mag * np.sin(alpha + theta)]
            ])

        Fnet = Fa + Fr

        thetaD = np.arctan2(Fnet[1, 0], Fnet[0, 0])
        orientation = np.arctan2(
            np.sin(thetaD - theta),
            np.cos(thetaD - theta)
        )

        # ---------- CONTROL LAW ----------
        if np.linalg.norm(vector) < self.eps_control:
            xvel = 0.0
            thetavel = 0.0
        else:
            thetavel = self.ktheta * orientation
            xvel = 0.0 if abs(orientation) > self.eps_orient else np.linalg.norm(Fnet)

        xvel = min(xvel, 2.5)

        self.ControlVel.linear.x = float(xvel)
        self.ControlVel.angular.z = float(thetavel)
        self.VelocityPublisher.publish(self.ControlVel)




def main(args=None):

    rclpy.init(args=args)

    # --------- GLOBAL GOAL (LAT, LON) ---------
    goal_lat = -35.36305147 
   
    goal_lon =  149.16485313

    node = ControllerNode((goal_lat, goal_lon))
    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
